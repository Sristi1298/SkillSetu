# SkillSetu
A niche e-commerce platform that empowers rural and urban artisans to register, showcase, and sell their handmade products online. Inspired by the Desi Etsy concept, this mini marketplace bridges the gap between local creators and digital customers, enabling easy product discovery, seamless purchases, and artisan visibility.
